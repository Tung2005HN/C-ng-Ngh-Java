# Bao cao Lab 2 - Cong nghe Java

## 1. Thong tin bai lab

- Ten bai lab: Thiet lap moi truong Java, tao Maven project va dong goi JAR
- Ten du an: lab02-java-maven-jar
- groupId: vn.edu.eaut
- artifactId: lab02-java-maven-jar
- version: 1.0-SNAPSHOT
- Package: vn.edu.eaut.lab2
- Cong nghe: Java SE Console, JDK, JVM, Maven, JAR

## 2. Kiem tra moi truong

Da kiem tra cac lenh:

```bash
java -version
javac -version
mvn -version
echo $JAVA_HOME
```

Moi truong hien tai:

- Java Runtime: OpenJDK 21 (21.0.11-ea)
- Java Compiler: javac 21.0.11-ea
- Maven: Apache Maven 3.9.12
- Java runtime Maven nhan: /usr/lib/jvm/java-21-openjdk-amd64

Ghi chu: du `pom.xml` cau hinh bien dich muc tieu Java 17, JDK 21 dang cai dat van bien dich duoc
xuong bytecode tuong thich Java 17 (source/target = 17).

## 3. Cau truc du an

```text
lab02-java-maven-jar/
├── pom.xml
└── src/
    └── main/
        └── java/
            └── vn/
                └── edu/
                    └── eaut/
                        └── lab2/
                            ├── App.java
                            ├── Student.java
                            └── GradeCalculator.java
```

## 4. Cau hinh pom.xml

- `maven.compiler.source` / `maven.compiler.target` = 17 de bien dich bang Java 17.
- `project.build.sourceEncoding` = UTF-8.
- `maven-compiler-plugin` 3.13.0: bien dich ma nguon `.java` thanh `.class`.
- `maven-jar-plugin` 3.4.2: dong goi JAR va khai bao `mainClass` la
  `vn.edu.eaut.lab2.App` trong manifest de chay bang `java -jar`.

## 5. Mo ta chuong trinh

Ung dung Console nhap thong tin mot sinh vien, tinh diem tong ket hoc phan va xep loai.

- Lop `Student`: luu ma sinh vien, ho ten, diem chuyen can, diem giua ky, diem cuoi ky
  va cac phuong thuc getter.
- Lop `GradeCalculator`: chua logic tinh toan (tach rieng khoi giao dien):
  - `calculateFinalScore`: diem tong ket = chuyen can x 10% + giua ky x 30% + cuoi ky x 60%.
  - `classify`: xep loai A (>= 8.5), B (>= 7.0), C (>= 5.5), D (>= 4.0), F (< 4.0).
  - `validateScore`: bao loi neu diem nam ngoai khoang 0 - 10.
- Lop `App`: hien thi giao dien Console, nhap du lieu bang `Scanner`, kiem tra hop le diem
  (nhap lai neu sai), goi `GradeCalculator` va in ket qua.

## 6. Quy trinh bien dich va dong goi

Ma nguon `.java` duoc Maven bien dich bang JDK thanh bytecode `.class`. Maven dong goi cac
file `.class` thanh file `.jar`; manifest khai bao lop chinh `vn.edu.eaut.lab2.App` nen JAR
chay truc tiep bang JVM.

## 7. Lenh build va chay

```bash
# Dung tai thu muc goc cua project
mvn clean package

# Chay file JAR sau khi build thanh cong
java -jar target/lab02-java-maven-jar-1.0-SNAPSHOT.jar
```

Ket qua build: BUILD SUCCESS, sinh ra file `target/lab02-java-maven-jar-1.0-SNAPSHOT.jar`.

## 8. Kiem thu

Truong hop 1 - du lieu mau (SV001, Nguyen Van An, 8, 7, 9):

```text
Diem tong ket: 8.30
Xep loai: B
```

(8 x 0.1 + 7 x 0.3 + 9 x 0.6 = 8.30 -> B, dung theo dac ta.)

Truong hop 2 - kiem tra du lieu khong hop le (nhap 12 cho diem chuyen can):

```text
Loi: diem chuyen can phai nam trong khoang 0 den 10
```

Chuong trinh yeu cau nhap lai cho den khi diem hop le.

## 9. Loi gap phai va cach xu ly

- Bien moi truong `JAVA_HOME` khong duoc set trong shell nhung Maven van tim dung Java
  runtime qua duong dan JDK mac dinh cua he thong, nen build khong bi anh huong.
- `Double.parseDouble` nem `NumberFormatException` khi nhap ky tu khong phai so; da bat
  them ngoai le nay trong `App` de bao loi ro rang va yeu cau nhap lai.

## 10. Nhan xet ket qua

Du an dat day du yeu cau Buoi 2: dung cau truc Maven, tach lop `Student`, `GradeCalculator`,
`App`, cau hinh `pom.xml` voi compiler va jar plugin, build thanh cong va chay duoc file JAR
bang `java -jar`.
